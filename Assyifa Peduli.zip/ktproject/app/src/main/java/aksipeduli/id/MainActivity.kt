package aksipeduli.id

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatImageButton
import androidx.fragment.app.Fragment
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    val homeFramgent = HomeFragment()
    val newsFramgent = NewsFragment()
    val programFramgent = ProgramFragment()
    val profileFramgent = ProfileFragment()

    private lateinit var bottomNav: BottomNavigationView
    private lateinit var appBarLayout: AppBarLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        loadFragment(homeFramgent)

        bottomNav = findViewById(R.id.bottomnav)
        appBarLayout = findViewById(R.id.appBarLayout)

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_beranda -> {
                    loadFragment(homeFramgent)
                    appBarLayout.visibility = View.VISIBLE
                    true
                }
                R.id.nav_berita -> {
                    loadFragment(newsFramgent)
                    appBarLayout.visibility = View.VISIBLE
                    true
                }
                R.id.nav_program -> {
                    loadFragment(programFramgent)
                    appBarLayout.visibility = View.VISIBLE
                    true
                }
                R.id.nav_profile -> {
                    loadFragment(profileFramgent)
                    appBarLayout.visibility = View.GONE
                    true
                }
                else -> false
            }
        }

        findViewById<AppCompatImageButton>(R.id.notification_button).setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
        }
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.fragment_container, fragment)
            commitAllowingStateLoss()
        }
    }

    fun switchToNewsFragment() {
        supportFragmentManager.beginTransaction().replace(R.id.fragment_container, NewsFragment()).commitAllowingStateLoss()

        bottomNav.selectedItemId = R.id.nav_berita
    }
}