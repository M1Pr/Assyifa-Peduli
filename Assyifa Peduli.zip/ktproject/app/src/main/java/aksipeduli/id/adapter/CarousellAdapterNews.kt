package aksipeduli.id.adapter

import aksipeduli.id.R
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView

class CarousellAdapterNews(
    private val arrayList: ArrayList<Int>,
) : RecyclerView.Adapter<CarousellAdapterNews.ViewHolder>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.carousell_news, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val imageResource = arrayList[position]
        holder.imageView.setImageResource(imageResource)
    }

    override fun getItemCount(): Int = arrayList.size

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imageView: ImageView = view.findViewById(R.id.carousel_image_view)
    }
}